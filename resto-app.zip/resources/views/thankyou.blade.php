<x-guest-layout>

<!-- thank you section -->
<section id="menu" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h1 class="heading"> We wil get back to you soon.</h1>
				<hr>
			</div>
        </div>
        <div class="row">
			<div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h1 class=""> Thank you for your reservation!</h1>
			</div>
        </div>
    </div>
</section>

</x-guest-layout>
